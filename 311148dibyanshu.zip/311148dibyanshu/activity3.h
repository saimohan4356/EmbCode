#ifndef ACTIVITY3_H_INCLUDED
#define ACTIVITY3_H_INCLUDED
#include <avr/io.h>
#include <util/delay.h>

/**
 * Function Definitions
 */

/**
 * @brief To blink the led when a person occuipes seat and switch on the heater
 *
 * @param state Pin level to which the LED Pin should be set
 */
void timer();

char PWM(uint16_t temp);




#endif // ACTIVITY3_H_INCLUDED
