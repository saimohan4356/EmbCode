#include "activity1.h"
#include "activity2.h"
#include "activity3.h"

/*header files*/

/**
 * @brief Initialize all the Peripherals and pin configurations
 */





/**
 * @brief Main function where the code execution starts
 * @return int Return 0 if the program completes successfully
 * @note  if pin 0 of port C is high then pin 4 of port B is high
 * @note if above condition is not true then pin 4 of port B remain constant
 */



char temp_data;
int main(void)
{
	/* Initialize Peripherals */
    InitADC();
    char temp_data;
    uint16_t temp;
	peripheral_init();
    timer();

	while (1)
	{
        change_led_state(PD0);
		delay_ms(1000);
         temp=ReadADC(0);
        delay_ms(200);
        temp_data = PWM(temp);

        delay_ms(200);
	}
	return 0;
}
